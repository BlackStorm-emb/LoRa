/*
 * Keyboard.h
 *
 *  Created on: Nov 4, 2021
 *      Author: Тлехас Алий
 */

#ifndef KEYBOARD2_INC_KEYBOARD2_H_
#define KEYBOARD2_INC_KEYBOARD2_H_

#include "main.h"
#include "key.h"

void Keyboard_begin();
char Keyboard_getKey();

#endif /* KEYBOARD2_INC_KEYBOARD2_H_ */
