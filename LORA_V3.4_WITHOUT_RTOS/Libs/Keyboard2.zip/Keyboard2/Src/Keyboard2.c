/*
 * Keyboard2.c
 *
 *  Created on: Nov 4, 2021
 *      Author: Тлехас Алий
 */

#include "keyboard2.h"

#define ROWS 6
#define COLS 5

typedef struct {
	int pin;
	GPIO_TypeDef *port;
} Keyboard_dio_t;

static const Keyboard_dio_t colPins[COLS] = {
		{K_1_Pin, K_1_GPIO_Port},
		{K_2_Pin, K_2_GPIO_Port},
		{K_3_Pin, K_3_GPIO_Port},
		{K_4_Pin, K_4_GPIO_Port},
		{K_5_Pin, K_5_GPIO_Port}
};

static const Keyboard_dio_t rowPins[ROWS] = {
		{A_Pin, A_GPIO_Port},
		{B_Pin, B_GPIO_Port},
		{C_Pin, C_GPIO_Port},
		{D_Pin, D_GPIO_Port},
		{E_Pin, E_GPIO_Port},
		{F_Pin, F_GPIO_Port},
};

#define makeKeymap(x) ((char*)x)

#define KEY_ENTER 10
#define KEY_SHIFT 32
#define KEY_DOWN 90

const static char symbolKeys[ROWS][COLS] = {
		{'Q', 'W', 'E', 'R', 'T',},
		{'Y', 'U', 'I', 'O', 'P',},
		{'A', 'S', 'D', 'F', 'G',},
		{'H', 'J', 'K', 'L', 'Z',},
		{'X', 'C', 'V', 'B', 'N',},
		{'M', ' ', KEY_ENTER, KEY_SHIFT, KEY_DOWN}
};


#define MAPSIZE 6

typedef struct {
	uint16_t bitMap[MAPSIZE];
	Key_t current_key;
	uint32_t holdTimer;
} Keyboard_t;

static Keyboard_t Keyboard;
static char* keymap;
static uint32_t startTime;
const static uint16_t debounceTime = 50;
const static uint16_t holdTime = 300;

void scanKeys();
void nextKeyState(_Bool button);


void Keyboard_begin() {
	keymap = makeKeymap(symbolKeys);

	for (uint8_t r = 0; r < ROWS; r++) {
			HAL_GPIO_WritePin(rowPins[r].port, rowPins[r].pin, SET);
	}
}

char Keyboard_getKey() {
	if ( (HAL_GetTick() - startTime) > debounceTime ) {
		scanKeys();
		for (uint8_t r=0; r < ROWS; r++) {
			for (uint8_t c = 0; c < COLS; c++)  {
				_Bool button = bitRead(Keyboard.bitMap[r], c);
				char keyChar = keymap[r * COLS + c];
				int keyCode = r * COLS + c;
				if (button && Keyboard.current_key.kstate == IDLE) {
					Keyboard.current_key.kchar = keyChar;
					Keyboard.current_key.kcode = keyCode;
					nextKeyState(button);
				}
				else if (keyCode == Keyboard.current_key.kcode) {
					nextKeyState(button);
				}
			}
		}

		if (Keyboard.current_key.stateChanged && Keyboard.current_key.kstate == PRESSED) {
			return Keyboard.current_key.kchar;
		}
	}
	return NO_KEY;
}

void scanKeys() {
	for (uint8_t r = 0; r < ROWS; r++) {
		HAL_GPIO_WritePin(rowPins[r].port, rowPins[r].pin, RESET);
		for (uint8_t c = 0; c < COLS; c++) {
			bitWrite(&(Keyboard.bitMap[r]), c, !HAL_GPIO_ReadPin(colPins[c].port,colPins[c].pin));
		}
		HAL_GPIO_WritePin(rowPins[r].port, rowPins[r].pin, SET);
	}
}

void nextKeyState(_Bool button) {
	Keyboard.current_key.stateChanged = 0;
	switch (Keyboard.current_key.kstate) {
		case IDLE:
			if (button == 1) {
				Keyboard.current_key.kstate = PRESSED;
				Keyboard.current_key.stateChanged = 1;
				Keyboard.holdTimer = HAL_GetTick();
			}
			break;
		case PRESSED:
			if ((HAL_GetTick() - Keyboard.holdTimer) > holdTime) {
				Keyboard.current_key.kstate = HOLD;
				Keyboard.current_key.stateChanged = 1;
			}
			else if (button == 0) {
				Keyboard.current_key.kstate = RELEASED;
				Keyboard.current_key.stateChanged = 1;
			}
			break;
		case HOLD:
			if (button == 0){
				Keyboard.current_key.kstate = RELEASED;
				Keyboard.current_key.stateChanged = 1;
			}
			break;
		case RELEASED: {
			Keyboard.current_key.kstate = IDLE;
			Keyboard.current_key.stateChanged = 1;
		}
			break;
	}
}




